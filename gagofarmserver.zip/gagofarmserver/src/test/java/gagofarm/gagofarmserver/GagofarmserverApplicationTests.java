package gagofarm.gagofarmserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GagofarmserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
