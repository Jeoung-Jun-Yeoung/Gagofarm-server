package gagofarm.gagofarmserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GagofarmserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(GagofarmserverApplication.class, args);
	}

}
